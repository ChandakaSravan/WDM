<?php
require 'vendor/autoload.php'; // Assuming you have the Google Cloud SDK installed via Composer

use Google\Cloud\Storage\StorageClient;

// Set Google Cloud Storage Config
$projectId = 'cse5335';
$keyFilePath = './application_default_credentials.json'; 
$bucketName = 'cse5335_sxc9166'; 

$storage = new StorageClient([
    'projectId' => $projectId,
    'keyFilePath' => $keyFilePath
]);

$bucket = $storage->bucket($bucketName);

// Handle Image Upload
if (isset($_FILES['userfile'])) {
    $file = $_FILES['userfile'];
    $bucket->upload(fopen($file['tmp_name'], 'r'), [
        'name' => $file['name']
    ]);
}

// Handle Image Display
if (isset($_GET['display'])) {
    $object = $bucket->object($_GET['display']);
    $object->downloadToFile('./tmp/' . $_GET['display']);
    $currentImage = './tmp/' . $_GET['display'];
}

// Handle Image Deletion
if (isset($_GET['delete'])) {
    $object = $bucket->object($_GET['delete']);
    $object->delete();
}

// Fetch list of images
$objects = $bucket->objects();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Photo Album</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 50px;
            background-color: #f4f4f4;
        }

        /* Upload Form Styles */
        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        input[type="file"] {
            padding: 10px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #333;
            color: #ffffff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        /* Image List Styles */
        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            background-color: #ffffff;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        ul li a {
            text-decoration: none;
            color: #333;
            margin-right: 10px;
        }

        ul li a:hover {
            text-decoration: underline;
        }

        /* Image Display Styles */
        img {
            max-width: 80%;
            display: block;
            margin: 20px auto;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
    </style>
    <h1> A Photo Album using Google Cloud Storage</h1>
</head>
<body>

<!-- Upload Form -->
<form action="album.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="userfile">
    <input type="submit" value="Upload">
</form>

<!-- Image List -->
<ul>
    <?php foreach ($objects as $object): ?>
        <li>
            <a href="album.php?display=<?php echo $object->name(); ?>"><?php echo $object->name(); ?></a>
            <a href="album.php?delete=<?php echo $object->name(); ?>">Delete</a>
        </li>
    <?php endforeach; ?>
</ul>

<!-- Current Image Display -->
<?php if (isset($currentImage)): ?>
    <img src="<?php echo $currentImage; ?>" alt="Current Image">
<?php endif; ?>

</body>
</html>
