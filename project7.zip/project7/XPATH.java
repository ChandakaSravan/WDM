import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathConstants;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.xml.sax.InputSource;

public class xpath {

    public static void main(String[] args) throws Exception {
        DocumentBuilderFactory Factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = Factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource("path/to/SigmodRecord.xml"));

        XPathFactory xPathfactory = XPathFactory.newInstance();
        XPath xpath = xPathfactory.newXPath();

        // Query 1: Print the titles of all articles whose one of the authors is David Maier.
        NodeList nodeList1 = (NodeList) xpath.evaluate(
                "//article[authors/author='David Maier']/title",
                doc, XPathConstants.NODESET);
        printNodeList(nodeList1);

        // Query 2: Print the titles of all articles whose first author is David Maier.
        NodeList nodeList2 = (NodeList) xpath.evaluate(
                "//article[authors/author[1]='David Maier']/title",
                doc, XPathConstants.NODESET);
        printNodeList(nodeList2);

        // Query 3: Print the titles of all articles whose authors include David Maier and Stanley B. Zdonik.
        NodeList nodeList3 = (NodeList) xpath.evaluate(
                "//article[authors/author='David Maier' and authors/author='Stanley B. Zdonik']/title",
                doc, XPathConstants.NODESET);
        printNodeList(nodeList3);

        // Query 4: Print the titles of all articles in volume 19/number 2.
        NodeList nodeList4 = (NodeList) xpath.evaluate(
                "//issue[volume='19' and number='2']/articles/article/title",
                doc, XPathConstants.NODESET);
        printNodeList(nodeList4);

        // Query 5: Print the titles and the init/end pages of all articles in volume 19/number 2 whose authors include Jim Gray.
        NodeList nodeList5 = (NodeList) xpath.evaluate(
                "//issue[volume='19' and number='2']/articles/article[authors/author='Jim Gray']/title | " +
                "//issue[volume='19' and number='2']/articles/article[authors/author='Jim Gray']/initPage | " +
                "//issue[volume='19' and number='2']/articles/article[authors/author='Jim Gray']/endPage",
                doc, XPathConstants.NODESET);
        printNodeListWithPages(nodeList5);

        // Query 6: Print the volume and number of all articles whose authors include David Maier.
        NodeList nodeList6 = (NodeList) xpath.evaluate(
                "//article[authors/author='David Maier']/ancestor::issue/volume | " +
                "//article[authors/author='David Maier']/ancestor::issue/number",
                doc, XPathConstants.NODESET);
        printNodeList(nodeList6);
    }

    private static void printNodeList(NodeList nodeList) {
        for (int i = 0; i < nodeList.getLength(); i++) {
            System.out.println(nodeList.item(i).getTextContent());
        }
    }

    private static void printNodeListWithPages(NodeList nodeList) {
        for (int i = 0; i < nodeList.getLength(); i += 3) {
            System.out.println("Title: " + nodeList.item(i).getTextContent());
            System.out.println("Init Page: " + nodeList.item(i + 1).getTextContent());
            System.out.println("End Page: " + nodeList.item(i + 2).getTextContent());
        }
    }
}
