import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class xslt {

    public static void main(String[] args) throws Exception {
        TransformerFactory factory = TransformerFactory.newInstance();
        StreamSource xslStream = new StreamSource("path/to/recipes.xsl");
        Transformer transformer = factory.newTransformer(xslStream);

        StreamSource in = new StreamSource("path/to/recipes.xml");
        StreamResult out = new StreamResult(System.out); // or to a file: new StreamResult(new FileOutputStream("output.html"));
        transformer.transform(in, out);
    }
}
