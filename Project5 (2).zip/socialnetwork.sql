-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2023 at 10:08 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

-- Create the SocialNetwork database if it doesn't exist
CREATE DATABASE IF NOT EXISTS SocialNetwork;

-- Switch to the SocialNetwork database
USE SocialNetwork;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `user` varchar(10) DEFAULT NULL,
  `friend` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`user`, `friend`) VALUES
('sravan', 'sandeep'),
('sravan', 'akhil'),
('sandeep', 'akhil'),
('john', 'chetana'),
('chetana', 'avinash'),
('keerthi', 'avinash'),
('suraj', 'keerthi'),
('akhil', 'avinash'),
('avinash', 'akhil'),
('avinash', 'geethika'),
('akhil', 'chetana'),
('keerthi', 'chetana'),
('keerthi', 'harini'),
('harini', 'chetana');

-- --------------------------------------------------------

--
-- Create the SocialNetwork database if it doesn't exist
CREATE DATABASE IF NOT EXISTS SocialNetwork;

-- Switch to the SocialNetwork database
USE SocialNetwork;
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `fullname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `fullname`, `email`) VALUES
('akhil', 's123', 'Akhil Reddy', 'akhil@example.com'),
('avinash', '12345', 'Avinash Kumar', 'avinash@example.com'),
('chetana', 'c12345', 'Chetana S', 'chetana@example.com'),
('geethika', 'g12345', 'Geethika B', 'geethika@example.com'),
('harini', 'h12345', 'Harini P', 'harini@example.com'),
('john', 'j12345', 'John Smith', 'john@example.com'),
('keerthi', 'k12345', 'Keerthi R', 'keerthi@example.com'),
('sandeep', 'sa12345', 'Sandeep Reddy', 'sandeep@example.com'),
('sravan', 'sr12345', 'Sravan Kumar', 'sravan@example.com'),
('suraj', 'su12345', 'Suraj M', 'suraj@example.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
