<?php
session_start();

// If user is already logged in, redirect to social_network page
if (isset($_SESSION['username'])) {
    header("Location: social_network.php");
    exit;
}

// Database configuration
$host = '127.0.0.1';
$db = 'SocialNetwork';
$user = 'root';
$pass = ''; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

$message = "";

try {
    $dbh = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Fetch the password for the given username from the database
    $stmt = $dbh->prepare('SELECT password FROM users WHERE username = ?');
    $stmt->execute([$username]);
    
    if ($user = $stmt->fetch()) {
        if ($password == $user['password']) {
            $_SESSION['username'] = $username;
            header("Location: social_network.php");
            exit;
        } else {
            $message = "Invalid password!";
        }
    } else {
        $message = "Invalid username!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .login-container {
            background-color: #fff;
            width: 300px;
            margin: 50px auto;
            padding: 20px 40px;
            box-shadow: 0px 0px 10px #aaa;
            border-radius: 5px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #2d87f0;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #246dbd;
        }

        .error-message {
            color: #e74c3c;
            background-color: #f9e6e6;
            padding: 10px;
            border: 1px solid #e74c3c;
            margin-top: 15px;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Login</h2>
    <form action="login.php" method="post">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
        </div>
        <div class="form-group">
            <input type="submit" value="Login">
        </div>
    </form>
    <?php
    if (!empty($message)) {
        echo "<p class='error-message'>$message</p>";
    }
    ?>
</div>

</body>
</html>
