<?php
session_start();

// If the user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Database configuration
$host = '127.0.0.1';
$db = 'SocialNetwork';
$user = 'root';
$pass = ''; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $dbh = new PDO($dsn, $user, $pass, $options);

    // Get the user details
    $stmt = $dbh->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$_SESSION['username']]);
    $currentUser = $stmt->fetch();

    // Get the friends of the current user
    $stmt = $dbh->prepare('SELECT f.friend, u.fullname, u.email FROM friends f JOIN users u ON f.friend = u.username WHERE f.user = ?');
    $stmt->execute([$_SESSION['username']]);
    $friends = $stmt->fetchAll();

    // Get the non-friends of the current user
    $stmt = $dbh->prepare('SELECT username, fullname, email FROM users WHERE username NOT IN (SELECT friend FROM friends WHERE user = ?) AND username != ?');
    $stmt->execute([$_SESSION['username'], $_SESSION['username']]);
    $nonFriends = $stmt->fetchAll();

// Handle Add, Remove friend, and Logout
    if (isset($_GET['add'])) {
        // Code to add a friend
        $stmt = $dbh->prepare('INSERT INTO friends (user, friend) VALUES (?, ?)');
        $stmt->execute([$_SESSION['username'], $_GET['add']]);
        header("Location: social_network.php");
        exit;
    } elseif (isset($_GET['remove'])) {
        // Code to remove a friend
        $stmt = $dbh->prepare('DELETE FROM friends WHERE user = ? AND friend = ?');
        $stmt->execute([$_SESSION['username'], $_GET['remove']]);
        header("Location: social_network.php");
        exit;
    } elseif (isset($_GET['logout'])) {
        // Code to handle logout
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit;
    }

} catch (PDOException $e) {
    die('Database operation failed: ' . $e->getMessage());
}


//... [PHP code remains unchanged]

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Network</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            color: #333;
        }

        h2, h3 {
            color: #444;
        }

        header, section {
            max-width: 800px;
            margin: 2em auto;
            padding: 1em;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        ul {
            list-style-type: none;
            padding-left: 0;
        }

        li {
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            position: relative;
        }

        form {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        button {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        a {
            display: inline-block;
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #f44336;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        a:hover {
            background-color: #da190b;
        }
    </style>
</head>
<body>

<header>
    <h2>Welcome, <?= $currentUser['fullname'] ?>!</h2>
    <a href="social_network.php?logout=true">Logout</a>
</header>

<section>
    <h3>Your Details:</h3>
    <p>Username: <?= $currentUser['username'] ?></p>
    <p>Fullname: <?= $currentUser['fullname'] ?></p>
    <p>Email: <?= $currentUser['email'] ?></p>
</section>

<section>
    <h3>Friends</h3>
    <ul>
        <?php foreach ($friends as $friend): ?>
            <li>
                <?= $friend['friend'] ?> - <?= $friend['fullname'] ?> - <?= $friend['email'] ?>
                <form method="GET" action="social_network.php">
                    <button type="submit" name="remove" value="<?= $friend['friend'] ?>">Remove</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
</section>

<section>
    <h3>Others</h3>
    <ul>
        <?php foreach ($nonFriends as $nonFriend): ?>
            <li>
                <?= $nonFriend['username'] ?> - <?= $nonFriend['fullname'] ?> - <?= $nonFriend['email'] ?>
                <form method="GET" action="social_network.php">
                    <button type="submit" name="add" value="<?= $nonFriend['username'] ?>">Add</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
</section>

</body>
</html>


