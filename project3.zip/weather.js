let map;
let marker;

// Initialize the map with an initial center and add a click event listener
function initialize() {
  const initialCenter = { lat: 32.75, lng: -97.13 };
  
  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 8,
    center: initialCenter
  });

  // Add click event listener on the map
  map.addListener('click', event => {
    const { lat, lng } = event.latLng.toJSON();
    sendRequest({ lat, lng });
  });
}

// Trigger search using the city name
function searchCity() {
  const cityInput = document.getElementById('cityInput');
  if (cityInput) {
    const cityName = cityInput.value;
    sendRequest(cityName);
  }
}

// Send a request to the server based on query (coordinates or city name)
function sendRequest(query) {
  const xhr = new XMLHttpRequest();
  const url = typeof query === 'object' ?
    `proxy.php?lat=${query.lat}&lon=${query.lng}` :
    `proxy.php?q=${query}`;
  
  xhr.open("GET", url);
  xhr.setRequestHeader("Accept", "application/json");

  xhr.onreadystatechange = function() {
    if (this.readyState === 4) {
      if (this.status === 200) {
        const json = JSON.parse(this.responseText);
        weather_disp(json);  // Call the weather_disp function
      } else {
        console.error('Request failed', this.statusText);
      }
    }
  };
  
  xhr.send(null);
}

// Display weather report and place a marker on the map
function weather_disp(json) {
  // Convert temperature to degrees Celsius and Fahrenheit
  const temp_Celsius = (json.main.temp - 273.15).toFixed(2);
  const temp_Fah = ((json.main.temp - 273.15) * 9 / 5 + 32).toFixed(2);

  const outputDiv = document.getElementById("output");
  outputDiv.innerHTML = `
    <div class="weather-report">
      <h1>Weather Report for ${json.name}</h1>
      <div class="weather-parameter">
        <strong>Coordinates:</strong> Lat ${json.coord.lat}, Lon ${json.coord.lon}
      </div>
      <div class="weather-parameter">
        <strong>Weather:</strong> ${json.weather[0].description}
      </div>
      <div class="weather-parameter">
        <strong>Temperature:</strong> ${temp_Celsius} °C / ${temp_Fah} °F
      </div>
      <div class="weather-parameter">
        <strong>Feels Like:</strong> ${(json.main.feels_like - 273.15).toFixed(2)} °C / ${((json.main.feels_like - 273.15) * 9 / 5 + 32).toFixed(2)} °F
      </div>
      <div class="weather-parameter">
        <strong>Minimum Temperature:</strong> ${(json.main.temp_min - 273.15).toFixed(2)} °C / ${((json.main.temp_min - 273.15) * 9 / 5 + 32).toFixed(2)} °F
      </div>
      <div class="weather-parameter">
        <strong>Maximum Temperature:</strong> ${(json.main.temp_max - 273.15).toFixed(2)} °C / ${((json.main.temp_max - 273.15) * 9 / 5 + 32).toFixed(2)} °F
      </div>
      <div class="weather-parameter">
        <strong>Pressure:</strong> ${json.main.pressure} hPa
      </div>
      <div class="weather-parameter">
        <strong>Humidity:</strong> ${json.main.humidity}%
      </div>
      <div class="weather-parameter">
        <strong>Visibility:</strong> ${json.visibility} m
      </div>
      <div class="weather-parameter">
        <strong>Wind Speed:</strong> ${json.wind.speed} m/s
      </div>
      <div class="weather-parameter">
        <strong>Wind Degree:</strong> ${json.wind.deg}°
      </div>
      <div class="weather-parameter">
        <strong>Cloudiness:</strong> ${json.clouds.all}%
      </div>
      <div class="weather-parameter">
        <strong>Sunrise:</strong> ${new Date(json.sys.sunrise * 1000).toLocaleTimeString()}
      </div>
      <div class="weather-parameter">
        <strong>Sunset:</strong> ${new Date(json.sys.sunset * 1000).toLocaleTimeString()}
      </div>
    </div>
  `;

  // Place a marker on the map
  const location = new google.maps.LatLng(json.coord.lat, json.coord.lon);
  placeMarker(location);
}


// Place a marker on the map
function placeMarker(location) {
  if (marker) {
    marker.setMap(null);
  }
  marker = new google.maps.Marker({
    position: location,
    map: map
  });
  map.setCenter(location);
}
