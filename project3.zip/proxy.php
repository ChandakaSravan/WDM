<?php
  // put your API key here:
  $appid = "fdc886eb05fbf41582a42e3f2d863aaf";

  header("Content-type: application/json\n\n");
  $params = $_SERVER['QUERY_STRING'];
  $host = "https://api.openweathermap.org/data/2.5/weather?$params&APPID=$appid";
  $ch = curl_init($host);
  curl_exec($ch);
  curl_close($ch);
?>
