// Initialize array to hold soccer balls and set default speed and suspended state.
let soccer_balls = [];
let curr_speed = 1.0; 
let isSuspended = true;

// Initialize the application.
function initialize() {
    setBallNum();
}

// Set the number of soccer balls on the court.
function setBallNum() {
    const court = document.getElementById("court"); // Reference to the court element.
    const ballNums = document.getElementById("ballNums").value; // Get the desired number of balls.
    court.replaceChildren(); // Clear the court.
    soccer_balls = []; // Reset the soccer_balls array.

    let s = 0;
    // Create and position the specified number of soccer ball elements.
    while (s < ballNums) {
        const b = document.createElement("img");
        b.src = "soccer-ball.gif";
        b.style.height = "40px";
        b.style.position = "absolute";
        b.style.margin = "0";
        b.style.padding = "0px";
        
        // Position the soccer balls within the adjusted court dimensions.
        const lef_Bou = 10;
        const top_Bou = 105;
        const ball_diameter = 40;
        b.style.left = (Math.random() * (court.offsetWidth - ball_diameter - lef_Bou) + lef_Bou) + "px";
        b.style.top = (Math.random() * (court.offsetHeight - ball_diameter - top_Bou) + top_Bou) + "px";
        
        // Assign random velocities to the soccer balls.
        b.vx = (Math.random() * 2 - 1) * curr_speed;
        b.vy = (Math.random() * 2 - 1) * curr_speed;
        soccer_balls.push(b); // Add the ball to the array.
        court.appendChild(b); // Add the ball to the court.
        
        s++; // Increment the loop variable.
    }
}

// Function to get a random speed between min and max.
function get_Random_Speed(min, max) {
    return Math.random() * (max - min) + min;
}

let speedIncreaseFactor = 1; // Initialize the factor by which speed will increase.

// Set the speed of soccer balls.
function setSpeed(speed) {
    let min_speed, max_speed;
    
    // Increase the speedIncreaseFactor each time setSpeed is called.
    speedIncreaseFactor += 0.1; // Adjust the increase value as needed.
    
    // Determine min and max speed based on the input speed parameter.
    switch (speed) {
        case 0: // Slow
            min_speed = 1.5;
            max_speed = 2.5;
            break;
        case 1: // Medium
            min_speed = 5.5;
            max_speed = 6.5;
            break;
        case 2: // Fast
            min_speed = 9.0;
            max_speed = 10.0;
            break;
    }
    
    // Apply the speedIncreaseFactor to the velocities of each soccer ball.
    for (let b of soccer_balls) {
        let randomDirectionX = (Math.random() < 0.5) ? -1 : 1;
        let randomDirectionY = (Math.random() < 0.5) ? -1 : 1;

        b.vx = randomDirectionX * get_Random_Speed(min_speed, max_speed) * speedIncreaseFactor;
        b.vy = randomDirectionY * get_Random_Speed(min_speed, max_speed) * speedIncreaseFactor;
    }
}

// Function to resume or suspend the movement of soccer balls.
function resumeOrSuspend(event) {
    if (isSuspended) {
        setInterval(move_soccer_balls, 20); // Start moving the soccer balls.
        isSuspended = false;
    } else {
        isSuspended = true; // Suspend the movement.
    }
}

// Check if two elements are colliding.
function isColliding(b1, b2) {
    const r1 = b1.getBoundingClientRect();
    const r2 = b2.getBoundingClientRect();

    // Check for overlapping of rectangles.
    return (
        r1.left < r2.right &&
        r1.right > r2.left &&
        r1.top < r2.bottom &&
        r1.bottom > r2.top
    );
}

// Move the soccer balls within the court.
function move_soccer_balls() {
    if (isSuspended) {
        return; // Exit if movement is suspended.
    }

    const court = document.getElementById("court");
    let index = 0;

    // Iterate through all soccer balls and move them.
    while (index < soccer_balls.length) {
        let b = soccer_balls[index];
        let x = parseFloat(b.style.left);
        let y = parseFloat(b.style.top);
        let nx = x + b.vx;
        let ny = y + b.vy;

        // Adjust x-coordinate to keep the ball within the court.
        if (nx < 0 + 10) {
            b.vx = Math.abs(b.vx);
            nx = 10;
        } else if (nx > court.offsetWidth - 40) {
            b.vx = -Math.abs(b.vx);
            nx = court.offsetWidth - 40;
        }

        // Adjust y-coordinate to keep the ball within the court.
        if (ny < 0 + 105) {
            b.vy = Math.abs(b.vy);
            ny = 105;
        } else if (ny > court.offsetHeight - 40 + 105) {
            b.vy = -Math.abs(b.vy);
            ny = court.offsetHeight - 40 + 105;
        }

        b.style.left = nx + "px"; // Update the position of the ball.
        b.style.top = ny + "px";

        let innerIndex = 0

               // Iterate through all soccer balls for collision detection.
        while (innerIndex < soccer_balls.length) {
            let neigh_Ball = soccer_balls[innerIndex];
            // Check if the current ball is not the same as the neighbor ball and if they are colliding.
            if (b !== neigh_Ball && isColliding(b, neigh_Ball)) {
                // Swap the velocities of the colliding balls.
                [b.vx, neigh_Ball.vx] = [neigh_Ball.vx, b.vx];
                [b.vy, neigh_Ball.vy] = [neigh_Ball.vy, b.vy];
            }
            innerIndex++; // Increment the inner loop variable.
        }

        index++; // Increment the outer loop variable.
    }
}

// Initialize the application when the window loads.
window.onload = initialize;

