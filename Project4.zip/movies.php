

<!DOCTYPE html>
<html>
<head>
    <title>Movie Web Application</title>
</head>
<body>

<h1>Movie Web Application</h1>

<!-- Search Form -->
<form method="GET">
    <label for="search-input">Movie Title:</label>
    <input type="text" id="search-input" name="search" placeholder="Enter movie title">
    <button type="submit">Display Info</button>
</form>

<?php
if (isset($_GET['search'])) {
    // If a search query is provided, display search results.
    $searchQuery = urlencode($_GET['search']);
    displaySerRes($searchQuery);
} elseif (isset($_GET['id'])) {
    // If a movie ID is provided, display movie information.
    $movieId = $_GET['id'];
    displayMovieInfo($movieId);
}

function displaySerRes($query) {
    $url = "https://api.themoviedb.org/3/search/movie?query={$query}&api_key=124285860782b73b07ee8e1d121b44c9";
    $response = file_get_contents($url);
    $data = json_decode($response, true);

    echo "<h2>Search Results:</h2>";
    echo "<ul>";
    foreach ($data['results'] as $movie) {
        echo "<li><a href='movies.php?id={$movie['id']}'>{$movie['title']} ({$movie['release_date']})</a></li>";
    }
    echo "</ul>";
}

function displayMovieInfo($movieId) {
    $url = "https://api.themoviedb.org/3/movie/{$movieId}?api_key=124285860782b73b07ee8e1d121b44c9";
    $movieResponse = file_get_contents($url);
    $movieData = json_decode($movieResponse, true);

    $creditsUrl = "https://api.themoviedb.org/3/movie/{$movieId}/credits?api_key=124285860782b73b07ee8e1d121b44c9";
    $creditsResponse = file_get_contents($creditsUrl);
    $creditsData = json_decode($creditsResponse, true);

    echo "<div>";
    echo "<img src='http://image.tmdb.org/t/p/w500/{$movieData['poster_path']}' alt='{$movieData['title']}' style='width: 300px; height: 450px;'>";
    echo "<div>";
    echo "<h2>{$movieData['title']}</h2>";
    echo "<p><strong>Genres:</strong> " . implode(', ', array_column($movieData['genres'], 'name')) . "</p>";
    echo "<p><strong>Movie Overview:</strong> {$movieData['overview']}</p>";
    echo "<p><strong>Top Cast:</strong> " . implode(', ', array_slice(array_column($creditsData['cast'], 'name'), 0, 5)) . "</p>";
    echo "</div>";
    echo "</div>";
}

?>

</body>
</html>
